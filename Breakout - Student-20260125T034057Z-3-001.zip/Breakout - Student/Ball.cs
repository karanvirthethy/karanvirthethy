﻿using System;
using System.Drawing;
using System.Numerics;

//Karanvir Thethy
//January 16, 2026
//This class is responsible for bouncing off a brick, paddle, and side wall
namespace Breakout
{
    internal class Ball
    {
        //*************************************************************
        //Fields
        //*************************************************************
        
        //Ball center position on screen
        private Vector2 mPosition;
        
        //Direction the ball is moving 
        private Vector2 mVelocity;
        
        //Movement speed in pixels per second
        private int mSpeed;
        
        //Radius of the ball
        private float mRadius;

        //*************************************************************
        //Constructors
        //*************************************************************
        public Ball()
        {
            mPosition = new Vector2(250f, 450f);
            mVelocity = NormalizeSafe(new Vector2(0f, -1f));
            mSpeed = 520;
            mRadius = 7f;
        }

        public Ball(Vector2 pos, Vector2 vel, int speed)
        {
            //Set initial position
            mPosition = pos;
            //Normalize velocity so speed stays consistent
            mVelocity = NormalizeSafe(vel);
            //Set movement speed
            mSpeed = speed;
            //Set radius
            mRadius = 7f;
        }

        //*************************************************************
        //Properties
        //*************************************************************

        //Returns current ball position
        public Vector2 Position => mPosition;
        //Returns normalized velocity direction
        public Vector2 Velocity => mVelocity;
        //Returns current speed
        public int CurrentSpeed => mSpeed;

        //Returns bounding rectangle for collision detection
        public RectangleF Rect
        {
            get
            {
                return new RectangleF(mPosition.X - mRadius, mPosition.Y - mRadius, mRadius * 2, mRadius * 2);
            }
        }

        //*************************************************************
        //Methods
        //*************************************************************
        
        //Moves the ball to a specific position
        public void SetPosition(float x, float y)
        {
            mPosition = new Vector2(x, y);
        }

        //Sets new movement direction
        public void SetVelocity(Vector2 v)
        {
            mVelocity = NormalizeSafe(v);
        }

        //Increases or decreases ball speed safely
        public void MultiplySpeed(float factor)
        {
            //Calculate new speed value
            float newSpeed = mSpeed * factor;

            //Clamp speed to prevent it from being too slow or too fast
            if (newSpeed < 420f) newSpeed = 420f;
            if (newSpeed > 1200f) newSpeed = 1200f;

            //Apply final speed
            mSpeed = (int)newSpeed;
        }

        public void Update(float TimePassed)
        {
            //Calculate total distance to move this frame
            float moveDist = mSpeed * TimePassed;

            //Split into smaller steps to prevent tunneling through bricks
            int Steps = (int)(moveDist / 6f) + 1;

            //Distance moved each step
            Vector2 Step = (mVelocity * moveDist) / Steps;

            //Apply movement step-by-step
            for (int i = 0; i < Steps; i++)
            {
                mPosition += Step;
            }
        }

        //Draws the ball on screen
        public void Draw(Graphics g, int x, int y)
        {
            RectangleF r = Rect;
            g.FillEllipse(Brushes.White, r);
            g.DrawEllipse(Pens.Black, r.X, r.Y, r.Width, r.Height);
        }

        //Safely normalizes a vector (prevents divide by zero)
        private Vector2 NormalizeSafe(Vector2 v)
        {
            float len = v.Length();

            //If vector length is almost zero, default upward direction
            if (len < 0.000001f) return new Vector2(0f, -1f);
            return v / len;
        }
    }
}
