﻿using System;
using System.Drawing;

//Karanvir Thethy
//January 16, 2026
//This class is responsible for the menu
namespace Breakout
{
    //*************************************************************
    //Enums
    //*************************************************************
    public enum MenuStates { MainMenu, Instructions, Controls, PowerUps }

    internal class Menu
    {
        //*************************************************************
        //Fields
        //*************************************************************
        private MenuStates mMenuState;

        //*************************************************************
        //Constructors
        //*************************************************************
        public Menu()
        {
            mMenuState = MenuStates.MainMenu;
        }

        //*************************************************************
        //Properties
        //*************************************************************
        public MenuStates MenuState
        {
            get { return mMenuState; }
            set { mMenuState = value; }
        }

        //*************************************************************
        //Methods
        //*************************************************************
        public void Draw(Graphics g, Rectangle play)
        {
            using (Font Title = new Font("Segoe UI", 40, FontStyle.Bold))
            using (Font Text = new Font("Segoe UI", 14, FontStyle.Regular))
            using (Font Small = new Font("Segoe UI", 11, FontStyle.Regular))
            {
                float cx = play.Left + play.Width / 2f;

                //Title
                SizeF ts = g.MeasureString("BREAKOUT", Title);
                g.DrawString("BREAKOUT", Title, Brushes.Black, cx - ts.Width / 2f, play.Top + 60);

                if (mMenuState == MenuStates.MainMenu)
                {
                    string lines =
                        "Press ENTER to Start\n" +
                        "Press I for Instructions\n" +
                        "Press C for Controls\n" +
                        "Press P for Power-Ups\n" +
                        "Press ESC to Quit";

                    SizeF s = g.MeasureString(lines, Text);
                    g.DrawString(lines, Text, Brushes.Black, cx - s.Width / 2f, play.Top + 170);
                }
                else if (mMenuState == MenuStates.Instructions)
                {
                    string Msg =
                        "Use the paddle to bounce the ball and clear bricks.\n" +
                        "If the ball goes past the paddle, a turn is lost.\n"; 
 
                    SizeF s = g.MeasureString(Msg, Text);
                    g.DrawString(Msg, Text, Brushes.Black, cx - s.Width / 2f, play.Top + 170);

                    g.DrawString("Press M to return", Small, Brushes.Black, play.Left + 20, play.Bottom - 40);
                }
                else if (mMenuState == MenuStates.Controls)
                {
                    string Msg =
                        "A / LEFT Arrow Key  = Move Left\n" +
                        "D / RIGHT Arrow Key = Move Right\n" +
                        "SPACE = Launch Ball\n" +
                        "ESC = Pause / Resume";

                    SizeF s = g.MeasureString(Msg, Text);
                    g.DrawString(Msg, Text, Brushes.Black, cx - s.Width / 2f, play.Top + 170);

                    g.DrawString("Press M to return", Small, Brushes.Black, play.Left + 20, play.Bottom - 40);
                }
                else if (mMenuState == MenuStates.PowerUps)
                {
                    string Msg =
                        "Expand: Paddle gets wider\n" +
                        "Sticky: Ball sticks for a few seconds\n" +
                        "MultiBall: Spawns extra balls\n" +
                        "Shield: Saves one ball from falling\n" +
                        "Slow: Slows time briefly";

                    SizeF s = g.MeasureString(Msg, Text);
                    g.DrawString(Msg, Text, Brushes.Black, cx - s.Width / 2f, play.Top + 170);

                    g.DrawString("Press M to return", Small, Brushes.Black, play.Left + 20, play.Bottom - 40);
                }
            }
        }
    }
}
