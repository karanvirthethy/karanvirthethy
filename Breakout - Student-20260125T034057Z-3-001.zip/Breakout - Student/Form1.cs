﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Numerics;
using System.Windows.Forms;

//Karanvir Thethy
//January 16, 2026
//Form1.cs for Computer Science CPT (Breakout)
namespace Breakout
{
    public enum GameStates { Menu, Playing, Paused, Win, GameOver }

    public partial class Form1 : Form
    {
        //*************************************************************
        //Fields
        //*************************************************************
        private Timer mTimer;

        //Game objects
        private Menu mMenu;
        private Paddle mPaddle;
        private Bricks mBricks;

        private List<Ball> mBalls;
        private List<PowerUp> mDrops;

        //Collision check
        private bool mBallJustBounced;

        //Input tracking
        private bool mLeftDown;
        private bool mRightDown;

        //Launch / Sticky hold
        private bool mBallHeld;
        //Seconds
        private float mStickyTimeLeft;

        //Saves once
        private bool mShieldActive;
        //Seconds
        private float mSlowTimeLeft;        

        //Stats
        private int mLives;
        private int mScore;

        //For 4 + 12 milestones
        private int mPaddleHits;
        //Once per life
        private bool mOrangeSpeedApplied;
        //Once per life
        private bool mRedSpeedApplied;

        //For shrink rule
        private bool mRedBrickDestroyed;
        //Only once per life/screen
        private bool mShrinkTriggered;

        //Must clear 2 screens 
        private int mScreensCleared;        

        private GameStates mGameState;

        private Random mRng;

        //*************************************************************
        //Constructor
        //*************************************************************
        public Form1()
        {
            InitializeComponent();

            DoubleBuffered = true;
            KeyPreview = true;

            mRng = new Random();

            mMenu = new Menu();
            mPaddle = new Paddle();
            mBricks = new Bricks();

            mBalls = new List<Ball>();
            mDrops = new List<PowerUp>();

            mTimer = new Timer();
            mTimer.Interval = 16; 
            mTimer.Tick += Timer_Tick;
            mTimer.Start();

            ResetRun();
        }

        //*************************************************************
        //Setup / Reset
        //*************************************************************
        
        //Resets the entire game
        private void ResetRun()
        {
            mLives = 3;
            mScore = 0;

            mScreensCleared = 0;

            mDrops.Clear();
            mBalls.Clear();

            //Build screen 1
            SetupScreen();          
            mMenu.MenuState = MenuStates.MainMenu;
            mGameState = GameStates.Menu;
        }

        //Sets up new level
        private void SetupScreen()
        {
            //Using built-in Rectangle to store the playable game area boundaries for collision checks and screen layout
            Rectangle Play = GetPlayArea();

            //Reset per-screen/life flags
            ResetPerLifeFlags();

            //Paddle
            float paddleY = Play.Bottom - 40;
            mPaddle.SetPosition(Play.Left + (Play.Width - mPaddle.Rect.Width) / 2f, paddleY);
            mPaddle.ResetSize();

            //First 2 screens = classic only
            if (mScreensCleared < 2)
            {
                mBricks.BuildLevel1(Play.Left, Play.Top + 30, Play.Width);
            }
            else
            {
                //Progressive difficulty levels
                mBricks.BuildLevel(mScreensCleared + 1, Play.Left, Play.Top + 30, Play.Width);
            }

            //Ball
            mDrops.Clear();
            mBalls.Clear();

            //Create starting ball above paddle
            Ball b = new Ball(new Vector2(mPaddle.CenterX, mPaddle.Rect.Y - 10), new Vector2(0, -1), 520);
            
            mBalls.Add(b);

            mBallHeld = true;
        }

        //Reset effects that should only last per life
        private void ResetPerLifeFlags()
        {
            mPaddleHits = 0;
            mOrangeSpeedApplied = false;
            mRedSpeedApplied = false;

            mRedBrickDestroyed = false;
            mShrinkTriggered = false;

            mShieldActive = false;
            mSlowTimeLeft = 0f;

            mStickyTimeLeft = 0f;
            mPaddle.State = PaddleStates.Normal;
        }

        //Returns the playable game area rectangle
        private Rectangle GetPlayArea()
        {
            return new Rectangle(20, 20, ClientSize.Width - 40, ClientSize.Height - 40);
        }

        //*************************************************************
        //Game Loop
        //*************************************************************
        private void Timer_Tick(object sender, EventArgs e)
        {
            float TimePassed = mTimer.Interval / 1000f;

            //Slow motion effect
            if (mSlowTimeLeft > 0f)
            {
                TimePassed *= 0.55f;
                mSlowTimeLeft -= (mTimer.Interval / 1000f);
            }

            if (mGameState == GameStates.Playing) UpdateGame(TimePassed);

            Invalidate();
        }

        private void UpdateGame(float TimePassed)
        {
            mBallJustBounced = false;

            Rectangle play = GetPlayArea();

            mPaddle.Update(TimePassed, mLeftDown, mRightDown, play.Left, play.Right);

            //Held ball stays on paddle
            if (mBallHeld && mBalls.Count > 0)
            {
                Ball b = mBalls[0];
                b.SetPosition(mPaddle.CenterX, mPaddle.Rect.Y - 10);
            }

            //Drops
            for (int i = mDrops.Count - 1; i >= 0; i--)
            {
                mDrops[i].Update(TimePassed);

                bool collected = mDrops[i].Rect.IntersectsWith(mPaddle.Rect);

                if (collected)
                {
                    ApplyPowerUp(mDrops[i].Type);
                    mDrops.RemoveAt(i);
                }
                else
                {
                    //Only check off-screen if it was NOT collected
                    if (mDrops[i].Rect.Top > play.Bottom + 60)
                    {
                        mDrops.RemoveAt(i);
                    }
                }
            }


            //Balls
            for (int i = mBalls.Count - 1; i >= 0; i--)
            {
                Ball ball = mBalls[i];
                mBallJustBounced = false;

                if (!mBallHeld || i != 0)
                    ball.Update(TimePassed);

                HandleWallCollisions(ball, play);

                bool paddleHit = HandlePaddleCollision(ball);
                if (paddleHit)
                {
                    mPaddleHits++;

                    //Speed intervals, after 4 hits and after 12 hits
                    if (mPaddleHits == 4 || mPaddleHits == 12)
                        ball.MultiplySpeed(1.15f);

                    if (mPaddle.State != PaddleStates.Sticky)
                        mBallHeld = false;
                }

                HandleBrickCollision(ball);

                //Ball lost (past paddle)
                if (ball.Rect.Top > play.Bottom + 40)
                {
                    //Shield saves once
                    if (mShieldActive)
                    {
                        mShieldActive = false;
                        ball.SetPosition(mPaddle.CenterX, mPaddle.Rect.Y - 10);
                        ball.SetVelocity(new Vector2(0, -1));
                        mBallHeld = true;
                    }
                    else
                    {
                        mBalls.RemoveAt(i);
                    }
                }
            }

            //If all balls gone, lose ONE life
            if (mBalls.Count == 0 && mGameState == GameStates.Playing)
            {
                mLives--;

                if (mLives <= 0)
                {
                    mGameState = GameStates.GameOver;
                    return;
                }

                //Reset per-life rules
                ResetPerLifeFlags();

                Ball b = new Ball(
                    new Vector2(mPaddle.CenterX, mPaddle.Rect.Y - 10),
                    new Vector2(0, -1),
                    520);

                mBalls.Add(b);
                mBallHeld = true;
            }

            //Sticky timer
            if (mStickyTimeLeft > 0f)
            {
                mStickyTimeLeft -= TimePassed;
                if (mStickyTimeLeft <= 0f)
                {
                    mPaddle.State = PaddleStates.Normal;
                    if (mBallHeld && mBalls.Count > 0) mBallHeld = false;
                }
            }

            //Screen cleared
            if (mBricks.AliveCount == 0)
            {
                mScreensCleared++;

                // WIN after 12 screens
                if (mScreensCleared >= 12)
                {
                    mGameState = GameStates.Win;
                    return;
                }

                // Go to next screen
                SetupScreen();
            }
        }

        //*************************************************************
        //Collisions
        //*************************************************************
        private void HandleWallCollisions(Ball ball, Rectangle play)
        {
            RectangleF r = ball.Rect;
            Vector2 v = ball.Velocity;

            float Radius = r.Width / 2f;

            //Left
            if (r.Left <= play.Left)
            {
                ball.SetPosition(play.Left + Radius, ball.Position.Y);
                ball.SetVelocity(new Vector2(-v.X, v.Y));
            }

            //Right
            else if (r.Right >= play.Right)
            {
                ball.SetPosition(play.Right - Radius, ball.Position.Y);
                ball.SetVelocity(new Vector2(-v.X, v.Y));
            }

            //Top
            if (r.Top <= play.Top)
            {
                ball.SetPosition(ball.Position.X, play.Top + Radius);
                ball.SetVelocity(new Vector2(v.X, -v.Y));

                // Shrink rule stays correct
                if (mRedBrickDestroyed && !mShrinkTriggered)
                {
                    mPaddle.ShrinkHalf();
                    mShrinkTriggered = true;
                }
            }
        }

        private bool HandlePaddleCollision(Ball ball)
        {
            if (mBallHeld) return false;

            RectangleF b = ball.Rect;
            RectangleF p = mPaddle.Rect;

            if (!b.IntersectsWith(p)) return false;

            //< m>ove ball above paddle
            ball.SetPosition(ball.Position.X, p.Top - b.Height / 2f - 1);

            float hitX = ball.Position.X - (p.Left + p.Width / 2f);
            float norm = hitX / (p.Width / 2f);

            double newVX = norm;
            double newVY = -Math.Sqrt(Math.Max(0.05, 1 - newVX * newVX));

            if (Math.Abs(newVX) < 0.08)
            {
                if (newVX < 0)
                    newVX = -0.08;
                else
                    newVX = 0.08;
            }

            ball.SetVelocity(new Vector2((float)newVX, (float)newVY));

            if (mPaddle.State == PaddleStates.Sticky)
                mBallHeld = true;

            return true;
        }

        private void HandleBrickCollision(Ball ball)
        {
            RectangleF b = ball.Rect;

            if (mBricks.TryHit(b, out BrickTypes hitType, out RectangleF hitRect,
                               out int baseScore, out bool destroyed, out bool spawnedDrop)) // out = gets returned collision results
            {
                //Bounce by overlap
                float overlapLeft = b.Right - hitRect.Left;
                float overlapRight = hitRect.Right - b.Left;
                float overlapTop = b.Bottom - hitRect.Top;
                float overlapBottom = hitRect.Bottom - b.Top;

                bool ballFromLeft = overlapLeft < overlapRight;
                bool ballFromTop = overlapTop < overlapBottom;

                float minX;
                if (ballFromLeft)
                    minX = overlapLeft;
                else
                    minX = overlapRight;

                float minY;
                if (ballFromTop)
                    minY = overlapTop;
                else
                    minY = overlapBottom;

                Vector2 v = ball.Velocity;

                if (!mBallJustBounced)
                {
                    if (minX < minY)
                    {
                        //Bounce left/right
                        ball.SetVelocity(new Vector2(-v.X, v.Y));

                        //Push out
                        if (ballFromLeft)
                            ball.SetPosition(ball.Position.X - (minX + 1), ball.Position.Y);
                        else
                            ball.SetPosition(ball.Position.X + (minX + 1), ball.Position.Y);
                    }
                    else
                    {
                        //Bounce up/down
                        ball.SetVelocity(new Vector2(v.X, -v.Y));

                        //Push out
                        if (ballFromTop)
                            ball.SetPosition(ball.Position.X, ball.Position.Y - (minY + 1));
                        else
                            ball.SetPosition(ball.Position.X, ball.Position.Y + (minY + 1));
                    }

                    mBallJustBounced = true;
                }

                //After first contact with ORANGE row
                if (hitType == BrickTypes.Orange && !mOrangeSpeedApplied)
                {
                    ball.MultiplySpeed(1.08f);
                    mOrangeSpeedApplied = true;
                }

                //After first contact with RED row
                if (hitType == BrickTypes.Red && !mRedSpeedApplied)
                {
                    ball.MultiplySpeed(1.08f);
                    mRedSpeedApplied = true;
                }

                //Track red destroyed for shrink rule
                if (destroyed && hitType == BrickTypes.Red)
                    mRedBrickDestroyed = true;

                //Scoring (PDF colors)
                mScore += baseScore;

                //Optional drops (only if SpecialDrop exists in later levels)
                if (spawnedDrop && mScreensCleared >= 2)
                {
                    PowerUpTypes t = RollPowerUp();
                    float cx = hitRect.Left + hitRect.Width / 2f - 11;
                    float cy = hitRect.Top + hitRect.Height / 2f - 11;
                    mDrops.Add(new PowerUp(t, cx, cy));
                }
            }
        }

        //*************************************************************
        //PowerUps
        //*************************************************************
        private PowerUpTypes RollPowerUp()
        {
            int Roll = mRng.Next(100);
            if (Roll < 22) return PowerUpTypes.Expand;
            if (Roll < 42) return PowerUpTypes.Sticky;
            if (Roll < 62) return PowerUpTypes.MultiBall;
            if (Roll < 80) return PowerUpTypes.Shield;
            return PowerUpTypes.Slow;
        }

        private void ApplyPowerUp(PowerUpTypes t)
        {
            if (t == PowerUpTypes.Expand)
            {
                mPaddle.Expand();
            }
            else if (t == PowerUpTypes.Sticky)
            {
                mPaddle.State = PaddleStates.Sticky;
                mStickyTimeLeft = 6.0f;
            }
            else if (t == PowerUpTypes.MultiBall)
            {
                if (mBalls.Count == 0) return;

                Ball src = mBalls[0];
                Vector2 v = src.Velocity;

                Ball b1 = new Ball(src.Position, new Vector2(v.X + 0.25f, v.Y), src.CurrentSpeed);
                Ball b2 = new Ball(src.Position, new Vector2(v.X - 0.25f, v.Y), src.CurrentSpeed);

                mBalls.Add(b1);
                mBalls.Add(b2);

                mBallHeld = false;
            }
            else if (t == PowerUpTypes.Shield)
            {
                mShieldActive = true;
            }
            else if (t == PowerUpTypes.Slow)
            {
                mSlowTimeLeft = 6.5f;
            }
        }

        //*************************************************************
        //Drawing
        //*************************************************************
        protected override void OnPaint(PaintEventArgs e)
        {

            base.OnPaint(e);

            Graphics g = e.Graphics;
            Rectangle play = GetPlayArea();

            //Background + border (light gray)
            g.Clear(Color.Gainsboro);
            g.DrawRectangle(Pens.Black, play);

            //Menu
            if (mGameState == GameStates.Menu)
            {
                mMenu.Draw(g, play);
                return;
            }

            //HUD
            using (Font hud = new Font("Segoe UI", 11, FontStyle.Bold))
            {
                g.DrawString($"Score: {mScore}", hud, Brushes.Black, play.Left, play.Top - 18);
                g.DrawString($"Lives: {mLives}", hud, Brushes.Black, play.Left + 140, play.Top - 18);
                g.DrawString($"Screen: {mScreensCleared + 1}", hud, Brushes.Black, play.Left + 260, play.Top - 18);

                if (mShieldActive)
                    g.DrawString("SHIELD", hud, Brushes.Purple, play.Left + 420, play.Top - 18);
            }

            //Objects
            mBricks.Draw(g, 0, 0);
            mPaddle.Draw(g, 0, 0);
            foreach (Ball b in mBalls) b.Draw(g, 0, 0);
            foreach (PowerUp p in mDrops) p.Draw(g);

            //Overlays
            if (mGameState == GameStates.Paused)
                DrawCenteredMessage(g, "PAUSED - ESC to resume");

            if (mGameState == GameStates.GameOver)
                DrawCenteredMessage(g, "GAME OVER - ENTER to restart");

            if (mGameState == GameStates.Win)
                DrawCenteredMessage(g, "YOU WIN! - ENTER to restart");
        }

        private void DrawCenteredMessage(Graphics g, string msg)
        {
            Rectangle play = GetPlayArea();
            using (Font f = new Font("Segoe UI", 18, FontStyle.Bold))
            {
                SizeF s = g.MeasureString(msg, f);
                float x = play.Left + (play.Width - s.Width) / 2f;
                float y = play.Top + (play.Height - s.Height) / 2f;
                g.DrawString(msg, f, Brushes.Black, x, y);
            }
        }

        //*************************************************************
        //Input
        //*************************************************************
        protected override void OnKeyDown(KeyEventArgs e)
        {

            base.OnKeyDown(e);

            //MENU navigation
            if (mGameState == GameStates.Menu)
            {
                if (e.KeyCode == Keys.I) { mMenu.MenuState = MenuStates.Instructions; return; }
                if (e.KeyCode == Keys.C) { mMenu.MenuState = MenuStates.Controls; return; }
                if (e.KeyCode == Keys.P) { mMenu.MenuState = MenuStates.PowerUps; return; }
                if (e.KeyCode == Keys.M) { mMenu.MenuState = MenuStates.MainMenu; return; }

                if (e.KeyCode == Keys.Enter)
                {
                    mGameState = GameStates.Playing;
                    return;
                }

                if (e.KeyCode == Keys.Escape)
                {
                    Close();
                    return;
                }
            }

            //Movement keys only during play/pause
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.A) mLeftDown = true;
            if (e.KeyCode == Keys.Right || e.KeyCode == Keys.D) mRightDown = true;

            //ENTER from end states
            if (e.KeyCode == Keys.Enter)
            {
                if (mGameState == GameStates.GameOver || mGameState == GameStates.Win)
                {
                    ResetRun();                 
                    mGameState = GameStates.Menu; 
                    return;
                }
            }

            //ESC pause/resume (and quit from menu handled above)
            if (e.KeyCode == Keys.Escape)
            {
                if (mGameState == GameStates.Playing)
                {
                    mGameState = GameStates.Paused;
                    return;
                }
                else if (mGameState == GameStates.Paused)
                {
                    mGameState = GameStates.Playing;
                    return;
                }
            }

            //SPACE launch (and sticky release)
            if (e.KeyCode == Keys.Space)
            {
                if (mGameState == GameStates.Playing && mBalls.Count > 0)
                {
                    if (mBallHeld)
                    {
                        mBallHeld = false;

                        //Small random launch direction
                        float Direction;
                        if (mRng.Next(2) == 0)
                            Direction = -0.35f;
                        else
                            Direction = 0.35f;
                        mBalls[0].SetVelocity(new Vector2(Direction, -1));
                    }
                }
            }
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            base.OnKeyUp(e);

            //Stop movement when key released
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.A) mLeftDown = false;
            if (e.KeyCode == Keys.Right || e.KeyCode == Keys.D) mRightDown = false;
        }
    }
}
