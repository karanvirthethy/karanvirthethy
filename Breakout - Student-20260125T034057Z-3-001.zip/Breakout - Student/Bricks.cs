﻿using System;
using System.Drawing;

//Karanvir Thethy
//January 16, 2026
//This class is responsible for populating the playing area with bricks, creating the level layouts, destroying bricks, calculating points, and drawing the bricks
namespace Breakout
{
    //*************************************************************
    //Enums
    //*************************************************************

    internal class Bricks
    {
        //*************************************************************
        //Fields
        //*************************************************************

        //2D grid of bricks
        private Brick[,] mBricks;

        //Current grid size
        private int mRows;
        private int mCols;

        //Brick sizing + spacing
        private float mBrickW;
        private float mBrickH;
        private float mPad;

        //Random generator for steel/strong/drop chance
        private Random mRng;

        //*************************************************************
        //Constructors
        //*************************************************************
        public Bricks()
        {
            //Breakout layout, 8 rows x 10 cols
            mRows = 8; 
            mCols = 10;

            //Width is calculated later
            mBrickW = 0f;

            //Fixed brick height and padding between bricks
            mBrickH = 20f;
            mPad = 0f;
            
            //Random used for level generation
            mRng = new Random();
            
            //Create initial brick array
            mBricks = new Brick[mRows, mCols];
        }

        //*************************************************************
        //Properties
        //*************************************************************

        //Expose current rows and columns
        public int Rows => mRows;
        public int Cols => mCols;

        //Counts how many breakable bricks are still alive (for level clear check)
        public int AliveCount
        {
            get
            {
                int count = 0;
                //Loop through grid
                for (int r = 0; r < mRows; r++)
                    for (int c = 0; c < mCols; c++)
                        //Only count bricks that are alive AND breakable
                        if (mBricks[r, c].IsAlive && mBricks[r, c].IsBreakable)
                            count++;
                return count;
            }
        }


        //*************************************************************
        //Methods
        //*************************************************************

        //Builds the Breakout Level 1 pattern 
        public void BuildLevel1(int startX, int startY, int playWidth)
        {
            //Layout
            mRows = 8;
            mCols = 10;

            //Make bricks fit perfectly across the play area
            mBrickW = (playWidth - (mCols + 1) * mPad) / mCols;

            //Recreate grid with correct size
            mBricks = new Brick[mRows, mCols];

            //Create each row
            for (int r = 0; r < mRows; r++)
            {
                //Pick row color based on row index (top rows are harder / higher score)
                BrickTypes rowType;

                if (r <= 1)
                    rowType = BrickTypes.Red;
                else if (r <= 3)
                    rowType = BrickTypes.Orange;
                else if (r <= 5)
                    rowType = BrickTypes.Green;
                else
                    rowType = BrickTypes.Yellow;

                //Create each brick in the row
                for (int c = 0; c < mCols; c++)
                {
                    float x = startX + mPad + c * (mBrickW + mPad);
                    float y = startY + mPad + r * (mBrickH + mPad);
                    RectangleF rect = new RectangleF(x, y, mBrickW, mBrickH);

                    mBricks[r, c] = new Brick(rowType, rect);
                }
            }
        }

        //Builds a harder preset Level 2 (more steel/strong/drop bricks)
        public void BuildLevel2(int startX, int startY, int playWidth)
        {
            //Harder: more Steel/Strong/Special
            mRows = 9;
            mCols = 10;

            //Fit bricks perfectly across width
            mBrickW = (playWidth - (mCols + 1) * mPad) / mCols;

            //New grid
            mBricks = new Brick[mRows, mCols];

            for (int r = 0; r < mRows; r++)
            {
                //Base color pattern by row
                BrickTypes baseType;

                if (r < 2)
                    baseType = BrickTypes.Red;
                else if (r < 4)
                    baseType = BrickTypes.Orange;
                else if (r < 6)
                    baseType = BrickTypes.Green;
                else
                    baseType = BrickTypes.Yellow;

                for (int c = 0; c < mCols; c++)
                {
                    //Position brick
                    float x = startX + mPad + c * (mBrickW + mPad);
                    float y = startY + mPad + r * (mBrickH + mPad);
                    RectangleF rect = new RectangleF(x, y, mBrickW, mBrickH);

                    //Start with base type, then possibly upgrade to special types
                    BrickTypes t = baseType;

                    //Random chance for special bricks
                    int roll = mRng.Next(100);

                    if (roll < 10) t = BrickTypes.Steel;
                    else if (roll < 26) t = BrickTypes.Strong;
                    else if (roll < 38) t = BrickTypes.SpecialDrop;

                    //Create brick
                    mBricks[r, c] = new Brick(t, rect);
                }
            }
        }

        //Checks if the ball hits any brick, returns info about what was hit
        //Out = returns extra collision data back to the caller
        public bool TryHit(RectangleF ballRect, out BrickTypes hitType, out RectangleF hitRect, out int scoreValue, out bool destroyed, out bool spawnedDrop) 
        {
            //Default outputs (in case of no collision)
            hitType = BrickTypes.None;
            hitRect = RectangleF.Empty;
            scoreValue = 0;
            destroyed = false;
            spawnedDrop = false;

            //Loop through every brick in grid
            for (int r = 0; r < mRows; r++)
            {
                for (int c = 0; c < mCols; c++)
                {
                    Brick b = mBricks[r, c];

                    //Only check bricks that still exist
                    if (b.IsAlive)
                    {
                        //Collision check using rectangles
                        if (b.Rect.IntersectsWith(ballRect))
                        {
                            //Return info about the brick that was hit
                            hitType = b.Type;
                            hitRect = b.Rect;
                            scoreValue = b.ScoreValue;

                            //Special drop bricks only spawn powerup if destroyed
                            bool wasSpecial = (b.Type == BrickTypes.SpecialDrop);

                            //Hit() returns whether it got destroyed by this hit
                            destroyed = b.Hit();

                            //Spawn drop only if it was special AND got destroyed
                            spawnedDrop = destroyed && wasSpecial;

                            //Store modified brick back into array
                            mBricks[r, c] = b;

                            return true;
                        }
                    }
                }
            }
            return false;

        }

        //Draw every brick
        public void Draw(Graphics g, int x, int y)
        {
            for (int r = 0; r < mRows; r++)
                for (int c = 0; c < mCols; c++)
                    mBricks[r, c].Draw(g, x, y);
        }
        
        //Creates a level based on level number (level 1 = classic, 2+ scales difficulty)
        public void BuildLevel(int level, int startX, int startY, int playWidth)
        {
            //Level 1 = classic only
            if (level <= 1)
            {
                BuildLevel1(startX, startY, playWidth);
                return;
            }

            //Always 10 columns
            mCols = 10;

            //Add more rows as level increases, but cap at 12 for playability
            mRows = Math.Min(12, 8 + (level / 2));

            //Fit perfectly
            mBrickW = (playWidth - (mCols + 1) * mPad) / mCols;

            //Create brick grid
            mBricks = new Brick[mRows, mCols];

            //Fill the grid using recursion
            FillBricksRecursive(level, 0, 0, startX, startY);
        }

        private bool IsSteel(int r, int c)
        {
            Brick b = mBricks[r, c];
            if (b == null) return false;
            return b.Type == BrickTypes.Steel && b.IsAlive;
        }

        private bool WouldCreateSteel2x2(int r, int c)
        {
            //Top-left 2x2
            if (r > 0 && c > 0)
                if (IsSteel(r - 1, c - 1) && IsSteel(r - 1, c) && IsSteel(r, c - 1))
                    return true;

            //Top-right 2x2
            if (r > 0 && c < mCols - 1)
                if (IsSteel(r - 1, c) && IsSteel(r - 1, c + 1) && IsSteel(r, c + 1))
                    return true;

            return false;   
        }


        //Recursive function to fill brick grid row-by-row, col-by-col
        private void FillBricksRecursive(int level, int r, int c, int startX, int startY)
        {
            //Base case: finished all rows
            if (r >= mRows) return;

            //If end of row, move to next row
            if (c >= mCols)
            {
                FillBricksRecursive(level, r + 1, 0, startX, startY);
                return;
            }

            //Classic base colors by row
            BrickTypes baseType;

            //Default color based on row (classic style)
            if (r <= 1)
                baseType = BrickTypes.Red;
            else if (r <= 3)
                baseType = BrickTypes.Orange;
            else if (r <= 5)
                baseType = BrickTypes.Green;
            else
                baseType = BrickTypes.Yellow;

            //Difficulty scaling: increase special brick chances as level rises
            int steelChance = Math.Min(15, 3 + level);
            int strongChance = Math.Min(40, 10 + level * 2);
            int dropChance = Math.Min(25, 8 + level);

            //Random roll 0-99
            int roll = mRng.Next(100);

            //Start as base type
            BrickTypes t = baseType;

            //Try Steel (ONLY if it won't create cage)
            if (roll < steelChance)
            {
                if (!WouldCreateSteel2x2(r, c))
                    t = BrickTypes.Steel;
            }

            //Try Strong
            if (t == baseType && roll < steelChance + strongChance)
                t = BrickTypes.Strong;

            //Ty SpecialDrop
            if (t == baseType && roll < steelChance + strongChance + dropChance)
                t = BrickTypes.SpecialDrop;

            //Position brick
            float x = startX + mPad + c * (mBrickW + mPad);
            float y = startY + mPad + r * (mBrickH + mPad);
            RectangleF rect = new RectangleF(x, y, mBrickW, mBrickH);

            //Create brick
            mBricks[r, c] = new Brick(t, rect);

            //Recurse to next column in the same row
            FillBricksRecursive(level, r, c + 1, startX, startY);
        }

    }
}