﻿using System.Drawing;

//Karanvir Thethy
//January 16, 2026
//This class is responsible for each individual brick on the playing area
namespace Breakout
{
    //*************************************************************
    //Enums
    //*************************************************************
    public enum BrickTypes
    {
        None,
        Yellow,
        Green,
        Orange,
        Red,
        Steel,        
        Strong,      
        SpecialDrop   
    }
    internal class Brick
    {
        //*************************************************************
        //Fields
        //*************************************************************

        private BrickTypes mBrickType;
        private int mHitsLeft;
        private RectangleF mRect;


        //*************************************************************
        //Constructors
        //*************************************************************

        public Brick()
        {
            mBrickType = BrickTypes.None;
            mHitsLeft = 0;
            mRect = new RectangleF(0, 0, 0, 0);
        }

        public Brick(BrickTypes type, RectangleF rect)
        {
            mBrickType = type;
            mRect = rect;

            mHitsLeft = 1;
            if (type == BrickTypes.Steel) mHitsLeft = int.MaxValue;
            if (type == BrickTypes.Strong) mHitsLeft = 2;
            if (type == BrickTypes.SpecialDrop) mHitsLeft = 1;
        }

        //*************************************************************
        //Properties
        //*************************************************************
        public BrickTypes Type => mBrickType;
        public RectangleF Rect => mRect;
        public bool IsAlive => mBrickType != BrickTypes.None;

        public int ScoreValue
        {
            get
            {
                //Scoring by color rows
                if (mBrickType == BrickTypes.Yellow) return 1;
                if (mBrickType == BrickTypes.Green) return 3;
                if (mBrickType == BrickTypes.Orange) return 5;
                if (mBrickType == BrickTypes.Red) return 7;

                //Extra bricks
                if (mBrickType == BrickTypes.Strong) return 8;
                if (mBrickType == BrickTypes.SpecialDrop) return 6;
                return 0;
            }
        }

        public bool IsBreakable => mBrickType != BrickTypes.Steel && mBrickType != BrickTypes.None;

        //*************************************************************
        //Methods
        //*************************************************************
        public bool Hit()
        {
            if (mBrickType == BrickTypes.None) return false;
            if (mBrickType == BrickTypes.Steel) return false;

            mHitsLeft--;
            if (mHitsLeft <= 0)
            {
                mBrickType = BrickTypes.None;
                //Destroyed
                return true;
            }
            //Still alive
            return false; 
        }

        public void Draw(Graphics g, int x, int y)
        {
            if (mBrickType == BrickTypes.None) return;

            Color c = Color.Gray;

            if (mBrickType == BrickTypes.Yellow)
                c = Color.Gold;
            else if (mBrickType == BrickTypes.Green)
                c = Color.LimeGreen;
            else if (mBrickType == BrickTypes.Orange)
                c = Color.Orange;
            else if (mBrickType == BrickTypes.Red)
                c = Color.Red;
            else if (mBrickType == BrickTypes.Steel)
                c = Color.SlateGray;
            else if (mBrickType == BrickTypes.Strong)
                c = Color.MediumPurple;
            else if (mBrickType == BrickTypes.SpecialDrop)
                c = Color.DeepSkyBlue;

            using (Brush b = new SolidBrush(c))
            {
                g.FillRectangle(b, mRect);
                g.DrawRectangle(Pens.Black, mRect.X, mRect.Y, mRect.Width, mRect.Height);
            }

            //Show durability for Strong bricks
            if (mBrickType == BrickTypes.Strong)
            {
                //Display remaining hits 
                g.DrawString(
                    mHitsLeft.ToString(),
                    new Font("Segoe UI", 9, FontStyle.Bold),
                    Brushes.White,
                    mRect.X + 6,
                    mRect.Y + 2);
            }

            if (mBrickType == BrickTypes.Steel)
            {
                g.DrawString("∞", new Font("Segoe UI", 10, FontStyle.Bold), Brushes.White, mRect.X + 6, mRect.Y + 1);
            }
        }

    }
}
