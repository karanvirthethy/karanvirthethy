﻿using System;
using System.Drawing;

//Karanvir Thethy
//January 16, 2026
//This class is responsible for the movement of the paddle
namespace Breakout
{
    public enum PaddleStates { Normal, Small, Long, Sticky }
    
    internal class Paddle
    {
        //*************************************************************
        //Fields
        //*************************************************************
        
        //Rectangle representing paddle position and size
        private RectangleF mRect;

        //Movement speed
        private float mSpeed;

        //Current paddle state
        private PaddleStates mState;
        
        //Default paddle width and height
        private float mNormalW;
        private float mH;

        //*************************************************************
        //Constructors
        //*************************************************************
        public Paddle()
        {
            //Default paddle size
            mNormalW = 130f;
            mH = 14f;

            //Initial paddle position and size
            mRect = new RectangleF(200, 520, mNormalW, mH);

            //Movement speed
            mSpeed = 720f;

            //Start in normal state
            mState = PaddleStates.Normal;
        }

        //*************************************************************
        //Properties
        //*************************************************************

        //Returns paddle collision rectangle
        public RectangleF Rect => mRect;

        //Returns X coordinate of paddle center
        public float CenterX => mRect.X + mRect.Width / 2f;

        public PaddleStates State
        {
            get { return mState; }
            set { mState = value; }
        }

        //*************************************************************
        //Methods
        //*************************************************************

        //Sets paddle position directly
        public void SetPosition(float x, float y)
        {
            mRect.X = x;
            mRect.Y = y;
        }

        //Applies new width while keeping paddle centered
        public void ApplyWidth(float newWidth)
        {
            float cx = CenterX;
            mRect.Width = Math.Max(50f, newWidth);
            mRect.X = cx - mRect.Width / 2f;
        }

        //Resets paddle back to normal size and state
        public void ResetSize()
        {
            mState = PaddleStates.Normal;
            ApplyWidth(mNormalW);
        }

        //Shrinks paddle to half size
        public void ShrinkHalf()
        {
            mState = PaddleStates.Small;
            ApplyWidth(mNormalW / 2f);
        }

        //Expands paddle size
        public void Expand()
        {
            mState = PaddleStates.Long;
            ApplyWidth(mNormalW * 1.45f);
        }

        //Handles paddle movement and boundary limits
        public void Update(float dt, bool moveLeft, bool moveRight, int playLeft, int playRight)
        {
            float dx = 0f;

            //Move left
            if (moveLeft) dx -= mSpeed * dt;
            //Move right
            if (moveRight) dx += mSpeed * dt;

            //Apply movement
            mRect.X += dx;

            //Keep paddle inside play area boundaries
            if (mRect.X < playLeft) mRect.X = playLeft;
            if (mRect.Right > playRight) mRect.X = playRight - mRect.Width;
        }

        //Draws paddle on screen
        public void Draw(Graphics g, int x, int y)
        {
            //x,y parameters kept to match template; paddle draws from internal rect
            using (Brush b = new SolidBrush(Color.FromArgb(30, 30, 30)))
            {
                //Draw filled paddle body
                g.FillRectangle(b, mRect);
                //Draw paddle outline
                g.DrawRectangle(Pens.Black, mRect.X, mRect.Y, mRect.Width, mRect.Height);
            }

            //Display sticky label when sticky powerup is active
            if (mState == PaddleStates.Sticky)
            {
                g.DrawString("STICKY", new Font("Segoe UI", 9, FontStyle.Bold), Brushes.Goldenrod, mRect.X, mRect.Y - 18);
            }
        }
    }
}