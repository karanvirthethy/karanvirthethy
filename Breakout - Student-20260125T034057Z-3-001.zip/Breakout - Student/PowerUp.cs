﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Karanvir Thethy
//January 16, 2026
//This class is responsible for the powerups 
namespace Breakout
{
    public enum PowerUpTypes { None, Expand, Sticky, MultiBall, Shield, Slow }

    internal class PowerUp
    {
        private PowerUpTypes mType;
        //Using built-in RectangleF to store the power-up's position and size for movement, collision detection, and drawing
        private RectangleF mRect;
        private float mFallSpeed;

        public PowerUp(PowerUpTypes type, float x, float y)
        {
            mType = type;
            mRect = new RectangleF(x, y, 22, 22);
            mFallSpeed = 190f;
        }

        public PowerUpTypes Type
        {
            get { return mType; }
        }
        public RectangleF Rect
        {
            get { return mRect; }
        }

        public void Update(float dt)
        {
            mRect.Y += mFallSpeed * dt;
        }

        public void Draw(Graphics g)
        {
            //Simple icon-style drawing
            Brush b = Brushes.White;
            if (mType == PowerUpTypes.Expand)
            {
                b = Brushes.LimeGreen;
            }
            else if (mType == PowerUpTypes.Sticky)
            {
                b = Brushes.Gold;
            }
            else if (mType == PowerUpTypes.MultiBall)
            {
                b = Brushes.DeepSkyBlue;
            }
            else if (mType == PowerUpTypes.Shield)
            {
                b = Brushes.Violet;
            }
            else if (mType == PowerUpTypes.Slow)
            {
                b = Brushes.Orange;
            }

            g.FillEllipse(b, mRect);
            g.DrawEllipse(Pens.Black, mRect.X, mRect.Y, mRect.Width, mRect.Height);
        }
    }
}
